package com.example.flutter_scaffolders

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
